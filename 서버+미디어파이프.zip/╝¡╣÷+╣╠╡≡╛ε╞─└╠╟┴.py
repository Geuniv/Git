# 라이브러리 
from operator import methodcaller
from flask import Flask, render_template, request, Response
#library import
import cv2
import mediapipe as mp
import numpy as np
from tensorflow.keras.models import load_model
from multiprocessing import Process ,Queue
import time

app = Flask(__name__)

#액션 구분 및 행동 길이 설정
actions =  ['best','ok']
seq_length = 30

#캐릭터 최소/최대크기 설정
char_min = 30
char_max = 150

#학습모델 로드
model = load_model('./static/model.h5')

# MediaPipe hands model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)
# pose =  mp_pose.Pose(
#     static_image_mode=True,
#     model_complexity=2,
#     enable_segmentation=True,
#     min_detection_confidence=0.5)

cap = cv2.VideoCapture(0)

#캠 너비 및 높이 로드
width_cam = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
height_cam = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

# 그림 너비 및 높이 기본값 설정 - None으로 설정 후 뒤에 변경 할 예정
width = None
height = None

#sequence 및 action 저장할 리스트 생성
seq = []
action_seq = []

#캐릭터 이미지 로드
img_char = cv2.imread('./static/bird.png',-1)

# 메인 서버
@app.route("/")
def hello_world():
    return render_template("main.html")

# 이미지 페이지 서버
@app.route("/image_page")
def first():
    return render_template("image_page.html")

# 메인카메라 서버
@app.route("/Camera")
def camera():
    return render_template("camera.html")

def gen(cap):
# 시간 및 카운터 설정
    start_time = time.time()
    text_counter = 0

    while cap.isOpened():
        ret, img = cap.read()

        img = cv2.flip(img, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        result = hands.process(img)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        if time.time() - start_time > 2:
            start_time = time.time()
        if result.multi_hand_landmarks is not None:
            for res in result.multi_hand_landmarks:
                joint = np.zeros((21, 4))
                for j, lm in enumerate(res.landmark):
                    joint[j] = [lm.x, lm.y, lm.z, lm.visibility]

                # Compute angles between joints
                v1 = joint[[0,1,2,3,0,5,6,7,0,9,10,11,0,13,14,15,0,17,18,19], :3] # Parent joint
                v2 = joint[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], :3] # Child joint
                v = v2 - v1 # [20, 3]
                # Normalize v
                v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]
                # Get angle using arcos of dot product
                angle = np.arccos(np.einsum('nt,nt->n',
                    v[[0,1,2,4,5,6,8,9,10,12,13,14,16,17,18],:], 
                    v[[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19],:])) # [15,]

                angle = np.degrees(angle) # Convert radian to degree
                # angle = np.append(angle,dist)
                d = np.concatenate([joint.flatten(), angle])

                seq.append(d)

                mp_drawing.draw_landmarks(img, res, mp_hands.HAND_CONNECTIONS)

                if len(seq) < seq_length:
                    continue
                
                input_data = np.expand_dims(np.array(seq[-seq_length:], dtype=np.float32), axis=0)

                y_pred = model.predict(input_data).squeeze()
                #학습모델 불러 맞는지 확인
                i_pred = int(np.argmax(y_pred))
                conf = y_pred[i_pred]
                #확률 90% 이상 일 때 action값 보여줌
                if conf < 0.9:
                    continue
                action = actions[i_pred]
                action_seq.append(action)
                #행동값이 적으면 일단 실행
                if len(action_seq) < 3:
                    continue
                #행동을 프레임으로 구분 - 마지막, 그 전, 그 전전이 같은 행동이면 교체
                this_action = '?'
                if action_seq[-1] == action_seq[-2] == action_seq[-3]:
                    this_action = action
                    #현재 행동이 무엇인가에 따라 실행 확대/축소
                    if this_action == actions[0]:          
                            if width is None:
                                width = 20
                                height = 20
                            else:
                                width = int(width * 1.2)
                                height = int(height * 1.2)
                            if width > char_max:
                                width = char_max
                            if height > char_max:
                                height = char_max
                    elif this_action == actions[1]:
                        if width is None:
                            width = 20
                            height = 20
                        else:
                            width = int(width * 0.8)
                            height = int(height * 0.8)
                            if width < char_min:
                                width = char_min
                            if height < char_min:
                                height= char_min
                    # 높이/너비 값 존재하면 캐릭터 출력                    
                    if width is not None:
                        # 합성 할 이미지 생성 -> 원본 사이즈 리사이즈 + alpha값 추출 -> 이미지 합성 위해서
                        # 합성 이미지 f(x) = img * (1-alpha) + img_manipulate * (alpha) => 알파값 : 0~1 사이로 조절을 위해 정규화
                        img_char_mani = cv2.resize(img_char, (width,height), interpolation=cv2.INTER_LINEAR)
                        alpha = img_char_mani[:,:,3]/255
                        #캐릭터를 어디에 표시할 지 width_cam / height_cam 변수값 조절을 통해 위치조절 가능 + 크기에 맞춰 캐릭터 출력
                        for i in range(3):
                            if width/2 == int(width/2) :
                                img[int(width_cam/2) -9-int(height/2):int(width_cam/2) -9+int(height/2),int(height_cam/2)-int(width/2):int(height_cam/2)+int(width/2),i] = img[int(width_cam/2) -9-int(height/2):int(width_cam/2) -9+int(height/2),int(height_cam/2)-int(width/2):int(height_cam/2)+int(width/2),i] * (1-alpha) + img_char_mani[:,:,i] * alpha
                # width 값이 있을 때 작동 - width 값 없으면 에러남!
                if width is not None:
                    img_char_mani = cv2.resize(img_char, (width,height), interpolation=cv2.INTER_LINEAR)
                    alpha = img_char_mani[:,:,3]/255
                    for i in range(3):
                        if width/2 == int(width/2) :
                            img[int(width_cam/2) -9-int(height/2):int(width_cam/2) -9+int(height/2),int(height_cam/2)-int(width/2):int(height_cam/2)+int(width/2),i] = img[int(width_cam/2) -9-int(height/2):int(width_cam/2) -9+int(height/2),int(height_cam/2)-int(width/2):int(height_cam/2)+int(width/2),i] * (1-alpha) + img_char_mani[:,:,i] * alpha    
                cv2.putText(img, f'{this_action.upper()}', org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
                # 시간이 2초 이상이면 화면 캡쳐
                if time.time() - start_time >= 2 :
                    cv2.imwrite(f'./image/capture_{time.time()}.png',img)
                    # 캡쳐 후 counter 추가
                    text_counter += 1
                # counter가 1보다 크면 실행
                for i in range(text_counter):
                    cv2.putText(img, 'captured', org=(30,30), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(0, 0, 0), thickness=2)
                    if text_counter >= 2:
                        text_counter = 0

        #손 없으면 캐릭터 없에고 출력 + width,height 리셋        
        else:
            width = None
            height = None

        cv2.imshow('img', img)
        if cv2.waitKey(1) == ord('q'):
            break
    cv2.destroyAllWindows()

# 카메라 서버
@app.route('/video_feed')
def video_feed():
    global cap
    if Response(gen(cap),mimetype='multipart/x-mixed-replace; boundary=frame'):
        return render_template("camera.html")    # 윈도우창이 출력시 카메라 페이지로 다시 돌아간다 
        
if __name__ == "__main__":
    app.run( debug = True)
